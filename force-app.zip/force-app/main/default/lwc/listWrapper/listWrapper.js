import { LightningElement, wire } from 'lwc';
import getLinesSorted from '@salesforce/apex/LineController.getLinesSorted';

const text = `Wlazł kotek na płotek
i mruga,
ładna to piosenka,
nie długa.
Nie długa, nie krótka,
lecz w sam raz,
zaśpiewaj koteczku,
jeszcze raz.`;

export default class ListWrapper extends LightningElement {

    jsList = [];

    @wire(getLinesSorted)
    apexList

    connectedCallback() {
        this.jsList = text.split('\n').sort((a, b) => b.length - a.length);
    }
}